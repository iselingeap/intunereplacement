﻿using ConsoleApp1.Entiteiten;
using Microsoft.Data.SqlClient;
using Newtonsoft.Json;
using System.Security.Cryptography;
using System.Text;
using System.Web.Http;
using System.Web.Http.SelfHost;

namespace ConsoleApp1.Service
{

    public class Datamanagement 
    {
        SqlConnection conn = new SqlConnection();
        SqlCommand cmd = new SqlCommand();

        public void startConnection()
        {
            var datasource = @"(localdb)\MSSQLLocalDB";//server
            var database = "MonitoringApp"; //database
            var username = @"johnny"; //username
            var password = "test"; //password
            string connString = $"Data Source={datasource};Initial Catalog={database};User ID={username};Password={password}";
            conn.ConnectionString = connString;
            cmd.Connection = conn;
            try
            {
                Console.WriteLine("Openning Connection ...");
                conn.Open();
                Console.WriteLine("Connection successful!");
            }
            catch (Exception e)
            {
                Console.WriteLine("Error: " + e.Message);
            }
        }

        public DevicesData convertJsonToSql(string json)
        {
    
            DevicesData data = JsonConvert.DeserializeObject<DevicesData>(json);
            return data;
        }


        public void checkIfUserHasTasks()
        {

        }

        public string getUserGUIDbyHWID(string hwid)
        {
            cmd.CommandText = "SELECT GUID FROM Laptops WHERE HWID = @hwid";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@hwid", hwid);
            object laptopIdObj = cmd.ExecuteScalar();
            string laptopGuid = laptopIdObj != null && laptopIdObj != DBNull.Value ? Convert.ToString(laptopIdObj): "";
            if (laptopGuid != "")
            {
                return laptopGuid;
            }
            else
            {
                throw new Exception("No laptop found with the provided HWID.");
            }
        }

        public string userLastTimeUpdate(string userId)
        {
            Random rnd = new Random();
            cmd.CommandText = "SELECT lastUpdate FROM Laptops where GUID = @guid";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@guid", userId);
            object result = cmd.ExecuteScalar();
            DateTime lastUpdateTime = Convert.ToDateTime(result);
            if (DateTime.Now > lastUpdateTime.AddMinutes(20 + rnd.Next(1,6)))
            {
                return "trueface";
            }
            else
            {
                return "falseface";
            }
        }

        public string getUserTasks(string userId)
        {
            cmd.CommandText = "SELECT  Tasks.task, Tasks.IsWinget, Tasks.status, Tasks.laptop_id FROM Laptops INNER JOIN Tasks ON Laptops.id = Tasks.laptop_id  where Laptops.GUID = @guid";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@guid", userId);
            object result = cmd.ExecuteScalar();
            string tasks = Convert.ToString(result);

            return tasks;


        }

        public void insertOrUpdateDatabase(DevicesData data)
        {
            using (var transaction = conn.BeginTransaction())
            {

                try
                {
                    cmd.Transaction = transaction;

                    // Check if laptop exists
                    cmd.CommandText = "SELECT id FROM Laptops WHERE HWID = @hwid";
                    cmd.Parameters.Clear();
                    cmd.Parameters.AddWithValue("@hwid", data.hwid ?? (object)DBNull.Value);
                    object laptopIdObj = cmd.ExecuteScalar();
                    int laptopId = laptopIdObj != null && laptopIdObj != DBNull.Value ? Convert.ToInt32(laptopIdObj) : -1;

                    var sqlMinDate = new DateTime(1753, 1, 1);

                    if (laptopId > 0)
                    {
                        // Update laptop
                        cmd.CommandText = @"UPDATE Laptops 
                    SET name = @name,
                    OS = @os,
                    OSVer = @osVer,
                    lastUpdate = @lastUpdate,
                    MAC = @Mac,
                    HWID = @hwid
                    WHERE HWID = @hwid";
                        cmd.Parameters.Clear();
                        cmd.Parameters.AddWithValue("@name", data.Name);
                        cmd.Parameters.AddWithValue("@os", data.Os);
                        cmd.Parameters.AddWithValue("@osVer", data.OsVer);
                        cmd.Parameters.AddWithValue("@lastUpdate",
                            data.LastUpdate < sqlMinDate ? (object)DBNull.Value : data.LastUpdate);
                        cmd.Parameters.AddWithValue("@Mac", data.mac);
                        cmd.Parameters.AddWithValue("@hwid", data.hwid);
                        cmd.ExecuteNonQuery();
                        Console.WriteLine("Existing record updated.");
                    }
                    else
                    {
                        // Insert laptop
                        cmd.CommandText = @"INSERT INTO Laptops (name, OS, OSVer, lastUpdate, MAC, HWID, GUID) 
                    OUTPUT INSERTED.id
                    VALUES (@name, @os, @osVer, @lastUpdate, @Mac, @hwid, @guid)";
                        cmd.Parameters.Clear();
                        cmd.Parameters.AddWithValue("@name", data.Name ?? (object)DBNull.Value);
                        cmd.Parameters.AddWithValue("@os", data.Os ?? (object)DBNull.Value);
                        cmd.Parameters.AddWithValue("@osVer", data.OsVer ?? (object)DBNull.Value);
                        cmd.Parameters.AddWithValue("@lastUpdate",
                            data.LastUpdate < sqlMinDate ? (object)DBNull.Value : data.LastUpdate);
                        cmd.Parameters.AddWithValue("@Mac", data.mac ?? (object)DBNull.Value);
                        cmd.Parameters.AddWithValue("@hwid", data.hwid ?? (object)DBNull.Value);
                        cmd.Parameters.AddWithValue("@guid", Guid.NewGuid().ToString());
                        laptopId = Convert.ToInt32(cmd.ExecuteScalar());
                        Console.WriteLine("New record inserted.");
                    }

                    // Insert/Update Apps table using laptop_id
                    foreach (var app in data.appsInfo)
                    {
                        // Check if app exists for this laptop using INNER JOIN
                        cmd.CommandText = @"
                        SELECT COUNT(*) 
                        FROM Apps 
                        INNER JOIN Laptops ON Apps.laptop_id = Laptops.id
                        WHERE Apps.laptop_id = @LaptopId AND Apps.app_id = @AppId";
                        cmd.Parameters.Clear();
                        cmd.Parameters.AddWithValue("@LaptopId", laptopId);
                        cmd.Parameters.AddWithValue("@AppId", app.Id ?? (object)DBNull.Value);
                        int appCount = (int)cmd.ExecuteScalar();

                        if (appCount > 0)
                        {
                            // Update app
                            cmd.CommandText = @"UPDATE Apps SET 
                            Name = @Name,
                            installedVersion = @InstalledVersion, 
                            AvailableVersions = @AvailableVersions, 
                            IsUpdateAvailable = @IsUpdateAvailable
                            WHERE laptop_id = @LaptopId AND app_id = @AppId";
                            cmd.Parameters.Clear();
                            cmd.Parameters.AddWithValue("@Name", app.Name);
                            cmd.Parameters.AddWithValue("@InstalledVersion", app.InstalledVersion ?? (object)DBNull.Value);
                            cmd.Parameters.AddWithValue("@AvailableVersions", app.AvailableVersions ?? (object)DBNull.Value);
                            cmd.Parameters.AddWithValue("@IsUpdateAvailable", app.IsUpdateAvailable);
                            cmd.Parameters.AddWithValue("@LaptopId", laptopId);
                            cmd.Parameters.AddWithValue("@AppId", app.Id ?? (object)DBNull.Value);
                            cmd.ExecuteNonQuery();
                        }
                        else
                        {
                            // Insert app
                            cmd.CommandText = @"INSERT INTO Apps (name,app_id, installedVersion, AvailableVersions, IsUpdateAvailable, laptop_id)
                            VALUES (@Name ,@AppId, @InstalledVersion, @AvailableVersions, @IsUpdateAvailable, @LaptopId)";
                            cmd.Parameters.Clear();
                            cmd.Parameters.AddWithValue("@Name", app.Name ?? (object)DBNull.Value);
                            cmd.Parameters.AddWithValue("@AppId", app.Id ?? (object)DBNull.Value);
                            cmd.Parameters.AddWithValue("@InstalledVersion", app.InstalledVersion ?? (object)DBNull.Value);
                            cmd.Parameters.AddWithValue("@AvailableVersions", app.AvailableVersions ?? (object)DBNull.Value);
                            cmd.Parameters.AddWithValue("@IsUpdateAvailable", app.IsUpdateAvailable);
                            cmd.Parameters.AddWithValue("@LaptopId", laptopId);
                            cmd.ExecuteNonQuery();
                        }
                    }

                    // Insert Winlogs table using laptop_id
                    if (data.winGetLog != null)
                    {
                        foreach (var log in data.winGetLog)
                        {
                            cmd.CommandText = @"INSERT INTO Winlogs (laptop_id, Logs, time) VALUES (@LaptopId, @Logs, @Time)";
                            cmd.Parameters.Clear();
                            cmd.Parameters.AddWithValue("@LaptopId", laptopId);
                            cmd.Parameters.AddWithValue("@Logs", log ?? (object)DBNull.Value);
                            cmd.Parameters.AddWithValue("@Time", DateTime.Now);
                            cmd.ExecuteNonQuery();
                        }
                    }

                    transaction.Commit();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    Console.WriteLine("Database error: " + ex.Message);
                }

            }

        }


        public string EncryptString(string plainText, string key)
        {
            byte[] iv = new byte[16];
            byte[] array;
            using var aes = Aes.Create();
            aes.Key = Encoding.UTF8.GetBytes(key);
            aes.IV = iv;
            ICryptoTransform encryptor = aes.CreateEncryptor(aes.Key, aes.IV);
            using (var memoryStream = new System.IO.MemoryStream())
            {
                using (var cryptoStream = new CryptoStream((System.IO.Stream)memoryStream, encryptor, CryptoStreamMode.Write))
                {
                    using (var streamWriter = new System.IO.StreamWriter((System.IO.Stream)cryptoStream))
                    {
                        streamWriter.Write(plainText);
                    }
                    array = memoryStream.ToArray();
                }
            }
            return Convert.ToBase64String(array);


        }

        public string DecryptString(string cipherText, string key)
        {
            byte[] iv = new byte[16];
            byte[] buffer = Convert.FromBase64String(cipherText);
            using var aes = Aes.Create();
            aes.Key = Encoding.UTF8.GetBytes(key);
            aes.IV = iv;
            ICryptoTransform decryptor = aes.CreateDecryptor(aes.Key, aes.IV);
            using (var memoryStream = new System.IO.MemoryStream(buffer))
            {
                using (var cryptoStream = new CryptoStream((System.IO.Stream)memoryStream, decryptor, CryptoStreamMode.Read))
                {
                    using (var streamReader = new System.IO.StreamReader((System.IO.Stream)cryptoStream))
                    {
                        return streamReader.ReadToEnd();
                    }
                }
            }
        }

    }

   
}


