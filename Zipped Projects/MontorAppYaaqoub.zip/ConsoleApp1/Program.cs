﻿using ConsoleApp1.Entiteiten;
using ConsoleApp1.Service;
using System.Net;
using System.Text;


internal class Program
{

    private static async Task Main(string[] args)
    {
        var dm = new Datamanagement();
        var httpListener = new HttpListener();
        httpListener.Prefixes.Add("http://192.168.1.6:5000/");
        dm.startConnection();
        httpListener.Start();

        while (true)
        {
            var context = await httpListener.GetContextAsync();
            Console.WriteLine("Client connected.");
            Task.Factory.StartNew(() => HandleHttpClient(context, dm));
        }
    }

    private static async Task HandleHttpClient(HttpListenerContext context, Datamanagement dm)
    {
        var request = context.Request;
        var method = request.HttpMethod;
        string type = context.Request.RawUrl;

        Console.WriteLine(type);
        if (type.StartsWith("/application/AreThereTasks?id="))
        {
            var id = type.Substring("/application/AreThereTasks?id=".Length);
            id = dm.DecryptString(id, "1234567890123456");
            string updates = dm.getUserTasks(id);
            Console.WriteLine(updates);
            updates = dm.EncryptString(updates, "1234567890123456");
            var buffer = Encoding.UTF8.GetBytes(updates);
            context.Response.StatusCode = (int)HttpStatusCode.OK;
            context.Response.ContentLength64 = buffer.Length;
            await context.Response.OutputStream.WriteAsync(buffer, 0, buffer.Length);
            context.Response.Close();
            Console.WriteLine("closed");

        }
        else if (type == "/application/jsonDataLog")
        {
            using var reader = new StreamReader(request.InputStream, request.ContentEncoding);
            var Ejson = await reader.ReadToEndAsync();
            var json = dm.DecryptString(Ejson, "1234567890123456");
            Console.WriteLine("Received data");
            context.Response.StatusCode = (int)HttpStatusCode.OK;
            DevicesData dataTest = dm.convertJsonToSql(json);
            dm.insertOrUpdateDatabase(dataTest);
        }
        else if (type != null && type.StartsWith("/application/WhoIsClient?hwid="))
        {
            var hwid = type.Substring("/application/WhoIsClient?hwid=".Length);
            hwid = dm.DecryptString(hwid, "1234567890123456");
            string userGuid = dm.getUserGUIDbyHWID(hwid);
            var responseString = dm.EncryptString(userGuid, "1234567890123456");
            var buffer = Encoding.UTF8.GetBytes(responseString);
            context.Response.StatusCode = (int)HttpStatusCode.OK;
            context.Response.ContentLength64 = buffer.Length;
            await context.Response.OutputStream.WriteAsync(buffer, 0, buffer.Length);
        }
        else if(method == "POST" || type == "/application/TasksReturnFromClient")
        {
            using var reader = new StreamReader(request.InputStream, request.ContentEncoding);
            var Ejson = await reader.ReadToEndAsync();
            var json = dm.DecryptString(Ejson, "1234567890123456");
            Console.WriteLine("Received TasksReturnFromClient:" + json);
            context.Response.StatusCode = (int)HttpStatusCode.OK;
        }
        else
        {
            context.Response.StatusCode = (int)HttpStatusCode.NotFound;
        }
        Console.WriteLine("closed");
        context.Response.Close();
    }

}