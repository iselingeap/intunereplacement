﻿using Microsoft.Data.SqlClient;
using System.Runtime.InteropServices;

namespace WebApplication5.Services
{
    public class DBItemManagement
    {
        string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=MonitoringApp;User ID=johnny;Password=test";

        public List<Dictionary<string, object>> GetAllLaptopData(List<string> gadColumns, string sorter)
        {
            var getAllData = new List<Dictionary<string, object>>();
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand($"SELECT * FROM Laptops {sorter}", connection))
                using (var reader = command.ExecuteReader())
                {
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        gadColumns.Add(reader.GetName(i));
                    }
                    while (reader.Read())
                    {
                        var row = new Dictionary<string, object>();
                        foreach (var col in gadColumns)
                        {
                            row[col] = reader[col];
                        }
                        getAllData.Add(row);
                    }
                }
            }
            return getAllData;
        }


        public List<Dictionary <string, object>> GetAllAppData( List<string> gadColumns, string sorter)
        {
            var getAllData = new List<Dictionary<string, object>>();
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand($"SELECT DISTINCT  name, app_id, installedVersion, AvailableVersions, IsUpdateAvailable FROM Apps {sorter}", connection))
                using (var reader = command.ExecuteReader())
                {
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        gadColumns.Add(reader.GetName(i));
                    }
                    while (reader.Read())
                    {
                        var row = new Dictionary<string, object>();
                        foreach (var col in gadColumns)
                        {
                            row[col] = reader[col];
                        }
                        getAllData.Add(row);
                    }
                }
            }
            return getAllData;
        }

        public List<Dictionary<string, object>> GetAllLaptopsUsingApp( List<string> gadColumns, string AppId, string Version)
        {
            var getAllData = new List<Dictionary<string, object>>();
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand($"SELECT Laptops.id, Laptops.name, Laptops.os, Laptops.osVer, Laptops.lastUpdate, Laptops.MAC, Laptops.HWID, Laptops.GUID FROM Laptops JOIN Apps ON Laptops.id = Apps.laptop_id WHERE Apps.app_id = '{AppId}' AND Apps.installedVersion = '{Version}' ", connection))
                {
                    using (var reader = command.ExecuteReader())
                    {
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            gadColumns.Add(reader.GetName(i));
                        }
                        while (reader.Read())
                        {
                            var row = new Dictionary<string, object>();
                            foreach (var col in gadColumns)
                            {
                                row[col] = reader[col];
                            }
                            getAllData.Add(row);
                        }
                    }
                }
            }
            return getAllData;

        }

        public List<Dictionary<string, object>> GetAllAppsOnLaptop( List<string> gadColumns, string LaptopId,string sorter = "")
        {
            var getAllData = new List<Dictionary<string, object>>();
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand($"SELECT DISTINCT id, name, app_id, installedVersion, AvailableVersions, IsUpdateAvailable FROM Apps WHERE laptop_id = '{LaptopId}' {sorter} ", connection))
                using (var reader = command.ExecuteReader())
                {
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        gadColumns.Add(reader.GetName(i));
                    }
                    while (reader.Read())
                    {
                        var row = new Dictionary<string, object>();
                        foreach (var col in gadColumns)
                        {
                            row[col] = reader[col];
                        }
                        getAllData.Add(row);
                    }
                }
            }
            return getAllData;
        }

        public List<Dictionary<string, object>> GetLaptops( string query)
        {
            var Data = new List<Dictionary<string, object>>();
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand(query, connection))
                using (var reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        do
                        {
                            var row = new Dictionary<string, object>();
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                row[reader.GetName(i)] = reader.GetValue(i);
                            }
                            Data.Add(row);
                        } while (reader.Read());
                    } 
                }
            }
            return Data;
        }
    }
}
