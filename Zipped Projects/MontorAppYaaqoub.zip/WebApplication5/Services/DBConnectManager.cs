﻿using Microsoft.Data.SqlClient;

namespace WebApplication5.Services
{
    public class DBConnectManager
    {
        private string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=MonitoringApp;User ID=johnny;Password=test";
        public string GetConnectionString()
        {
            return connectionString;
        }

        public void SetConnectionString(string newConnectionString)
        {
            connectionString = newConnectionString;
        }

        public void TestConnection()
        {
            using (var connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    Console.WriteLine("Connection successful.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Connection failed: {ex.Message}");
                }
            }
        }

        public bool ValidateUser(string gebruikers, string wachtwoord)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                string query = "SELECT COUNT(1) FROM Gebruikers WHERE gebruikersnaam = @gebruikersnaam AND wachtwoord = @wachtwoord AND IsAdmin = 1";
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@gebruikersnaam", gebruikers);
                    command.Parameters.AddWithValue("@wachtwoord", wachtwoord);

                    connection.Open();
                    int count = (int)command.ExecuteScalar();
                    return count > 0;
                }
            }
        }

    }
}
